import React, { useState } from 'react';

const UserForm = () => {
  const [user, setUser] = useState({ name: '', email: '', phone: '' });

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      <h2>User Form</h2>
      <input name="name" placeholder="Name" onChange={handleChange} />
      <input name="email" placeholder="Email" onChange={handleChange} />
      <input name="phone" placeholder="Phone" onChange={handleChange} />
    </div>
  );
};

export default UserForm;
